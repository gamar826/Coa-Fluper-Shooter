gdjs.GameCode = {};
gdjs.GameCode.localVariables = [];
gdjs.GameCode.idToCallbackMap = new Map();
gdjs.GameCode.GDplayerObjects1= [];
gdjs.GameCode.GDplayerObjects2= [];
gdjs.GameCode.GDplayerObjects3= [];
gdjs.GameCode.GDplayerObjects4= [];
gdjs.GameCode.GDground2Objects1= [];
gdjs.GameCode.GDground2Objects2= [];
gdjs.GameCode.GDground2Objects3= [];
gdjs.GameCode.GDground2Objects4= [];
gdjs.GameCode.GDbackground1Objects1= [];
gdjs.GameCode.GDbackground1Objects2= [];
gdjs.GameCode.GDbackground1Objects3= [];
gdjs.GameCode.GDbackground1Objects4= [];
gdjs.GameCode.GDcloudsObjects1= [];
gdjs.GameCode.GDcloudsObjects2= [];
gdjs.GameCode.GDcloudsObjects3= [];
gdjs.GameCode.GDcloudsObjects4= [];
gdjs.GameCode.GDmessageObjects1= [];
gdjs.GameCode.GDmessageObjects2= [];
gdjs.GameCode.GDmessageObjects3= [];
gdjs.GameCode.GDmessageObjects4= [];
gdjs.GameCode.GDGroundObjects1= [];
gdjs.GameCode.GDGroundObjects2= [];
gdjs.GameCode.GDGroundObjects3= [];
gdjs.GameCode.GDGroundObjects4= [];
gdjs.GameCode.GDBGGroundObjects1= [];
gdjs.GameCode.GDBGGroundObjects2= [];
gdjs.GameCode.GDBGGroundObjects3= [];
gdjs.GameCode.GDBGGroundObjects4= [];
gdjs.GameCode.GDFlatDarkJoystickObjects1= [];
gdjs.GameCode.GDFlatDarkJoystickObjects2= [];
gdjs.GameCode.GDFlatDarkJoystickObjects3= [];
gdjs.GameCode.GDFlatDarkJoystickObjects4= [];


gdjs.GameCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameCode.GDplayerObjects2, gdjs.GameCode.GDplayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDplayerObjects3[i].getBehavior("PlatformerObject").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDplayerObjects3[k] = gdjs.GameCode.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDplayerObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDplayerObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDplayerObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDplayerObjects3[i].flipX(false);
}
}
{for(var i = 0, len = gdjs.GameCode.GDplayerObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDplayerObjects3[i].getBehavior("PlatformerObject").simulateRightKey();
}
}
{for(var i = 0, len = gdjs.GameCode.GDplayerObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDplayerObjects3[i].setAnimation((gdjs.RuntimeObject.getVariableNumber(gdjs.GameCode.GDplayerObjects3[i].getVariables().get("walk"))));
}
}
}

}


{

gdjs.copyArray(gdjs.GameCode.GDplayerObjects2, gdjs.GameCode.GDplayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDplayerObjects3[i].getBehavior("PlatformerObject").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDplayerObjects3[k] = gdjs.GameCode.GDplayerObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDplayerObjects3.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDplayerObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDplayerObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDplayerObjects3[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}
{for(var i = 0, len = gdjs.GameCode.GDplayerObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDplayerObjects3[i].setAnimation((gdjs.RuntimeObject.getVariableNumber(gdjs.GameCode.GDplayerObjects3[i].getVariables().get("walk"))));
}
}
{for(var i = 0, len = gdjs.GameCode.GDplayerObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDplayerObjects3[i].flipX(true);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left"));
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDplayerObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDplayerObjects2[i].setAnimation((gdjs.RuntimeObject.getVariableNumber(gdjs.GameCode.GDplayerObjects2[i].getVariables().get("stand"))));
}
}
}

}


};gdjs.GameCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDplayerObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
}

}


};gdjs.GameCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.GameCode.GDplayerObjects2);
{for(var i = 0, len = gdjs.GameCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDplayerObjects2[i].returnVariable(gdjs.GameCode.GDplayerObjects2[i].getVariables().get("walk")).setNumber(0);
}
}
{for(var i = 0, len = gdjs.GameCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDplayerObjects2[i].returnVariable(gdjs.GameCode.GDplayerObjects2[i].getVariables().get("stand")).setNumber(1);
}
}
{for(var i = 0, len = gdjs.GameCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDplayerObjects2[i].returnVariable(gdjs.GameCode.GDplayerObjects2[i].getVariables().get("jump")).setNumber(2);
}
}
{for(var i = 0, len = gdjs.GameCode.GDplayerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDplayerObjects2[i].setAnimation((gdjs.RuntimeObject.getVariableNumber(gdjs.GameCode.GDplayerObjects2[i].getVariables().get("stand"))));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.GameCode.GDplayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDplayerObjects2[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDplayerObjects2[k] = gdjs.GameCode.GDplayerObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDplayerObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.GameCode.GDplayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDplayerObjects1.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDplayerObjects1[i].getBehavior("PlatformerObject").isOnFloor()) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDplayerObjects1[k] = gdjs.GameCode.GDplayerObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDplayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDplayerObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDplayerObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDplayerObjects1[i].setAnimation((gdjs.RuntimeObject.getVariableNumber(gdjs.GameCode.GDplayerObjects1[i].getVariables().get("jump"))));
}
}

{ //Subevents
gdjs.GameCode.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.GameCode.GDplayerObjects2);
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.GameCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDplayerObjects2[0].getPointX("")), "", 0);
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.GameCode.GDplayerObjects2);
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.GameCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDplayerObjects2[0].getPointX("")) * 0.5, "layer2", 0);
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.GameCode.GDplayerObjects2);
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.GameCode.GDplayerObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDplayerObjects2[0].getPointX("")) * 0.2, "layer3", 0);
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.GameCode.GDplayerObjects1);
{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.GameCode.GDplayerObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDplayerObjects1[0].getPointX("")) * 0.1, "layer4", 0);
}
}

}


};gdjs.GameCode.eventsList4 = function(runtimeScene) {

{


gdjs.GameCode.eventsList2(runtimeScene);
}


{


gdjs.GameCode.eventsList3(runtimeScene);
}


};

gdjs.GameCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameCode.GDplayerObjects1.length = 0;
gdjs.GameCode.GDplayerObjects2.length = 0;
gdjs.GameCode.GDplayerObjects3.length = 0;
gdjs.GameCode.GDplayerObjects4.length = 0;
gdjs.GameCode.GDground2Objects1.length = 0;
gdjs.GameCode.GDground2Objects2.length = 0;
gdjs.GameCode.GDground2Objects3.length = 0;
gdjs.GameCode.GDground2Objects4.length = 0;
gdjs.GameCode.GDbackground1Objects1.length = 0;
gdjs.GameCode.GDbackground1Objects2.length = 0;
gdjs.GameCode.GDbackground1Objects3.length = 0;
gdjs.GameCode.GDbackground1Objects4.length = 0;
gdjs.GameCode.GDcloudsObjects1.length = 0;
gdjs.GameCode.GDcloudsObjects2.length = 0;
gdjs.GameCode.GDcloudsObjects3.length = 0;
gdjs.GameCode.GDcloudsObjects4.length = 0;
gdjs.GameCode.GDmessageObjects1.length = 0;
gdjs.GameCode.GDmessageObjects2.length = 0;
gdjs.GameCode.GDmessageObjects3.length = 0;
gdjs.GameCode.GDmessageObjects4.length = 0;
gdjs.GameCode.GDGroundObjects1.length = 0;
gdjs.GameCode.GDGroundObjects2.length = 0;
gdjs.GameCode.GDGroundObjects3.length = 0;
gdjs.GameCode.GDGroundObjects4.length = 0;
gdjs.GameCode.GDBGGroundObjects1.length = 0;
gdjs.GameCode.GDBGGroundObjects2.length = 0;
gdjs.GameCode.GDBGGroundObjects3.length = 0;
gdjs.GameCode.GDBGGroundObjects4.length = 0;
gdjs.GameCode.GDFlatDarkJoystickObjects1.length = 0;
gdjs.GameCode.GDFlatDarkJoystickObjects2.length = 0;
gdjs.GameCode.GDFlatDarkJoystickObjects3.length = 0;
gdjs.GameCode.GDFlatDarkJoystickObjects4.length = 0;

gdjs.GameCode.eventsList4(runtimeScene);
gdjs.GameCode.GDplayerObjects1.length = 0;
gdjs.GameCode.GDplayerObjects2.length = 0;
gdjs.GameCode.GDplayerObjects3.length = 0;
gdjs.GameCode.GDplayerObjects4.length = 0;
gdjs.GameCode.GDground2Objects1.length = 0;
gdjs.GameCode.GDground2Objects2.length = 0;
gdjs.GameCode.GDground2Objects3.length = 0;
gdjs.GameCode.GDground2Objects4.length = 0;
gdjs.GameCode.GDbackground1Objects1.length = 0;
gdjs.GameCode.GDbackground1Objects2.length = 0;
gdjs.GameCode.GDbackground1Objects3.length = 0;
gdjs.GameCode.GDbackground1Objects4.length = 0;
gdjs.GameCode.GDcloudsObjects1.length = 0;
gdjs.GameCode.GDcloudsObjects2.length = 0;
gdjs.GameCode.GDcloudsObjects3.length = 0;
gdjs.GameCode.GDcloudsObjects4.length = 0;
gdjs.GameCode.GDmessageObjects1.length = 0;
gdjs.GameCode.GDmessageObjects2.length = 0;
gdjs.GameCode.GDmessageObjects3.length = 0;
gdjs.GameCode.GDmessageObjects4.length = 0;
gdjs.GameCode.GDGroundObjects1.length = 0;
gdjs.GameCode.GDGroundObjects2.length = 0;
gdjs.GameCode.GDGroundObjects3.length = 0;
gdjs.GameCode.GDGroundObjects4.length = 0;
gdjs.GameCode.GDBGGroundObjects1.length = 0;
gdjs.GameCode.GDBGGroundObjects2.length = 0;
gdjs.GameCode.GDBGGroundObjects3.length = 0;
gdjs.GameCode.GDBGGroundObjects4.length = 0;
gdjs.GameCode.GDFlatDarkJoystickObjects1.length = 0;
gdjs.GameCode.GDFlatDarkJoystickObjects2.length = 0;
gdjs.GameCode.GDFlatDarkJoystickObjects3.length = 0;
gdjs.GameCode.GDFlatDarkJoystickObjects4.length = 0;


return;

}

gdjs['GameCode'] = gdjs.GameCode;
